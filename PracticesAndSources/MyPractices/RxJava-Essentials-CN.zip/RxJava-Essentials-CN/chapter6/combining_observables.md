# 组合Observables

上一章中，我们学到如何转换可观测序列。我们也看到了`map()`,`scan()`,`groupBY()`,以及更多有用的函数的实际例子，它们帮助我们操作Observable来创建我们想要的Observable。

本章中，我们将研究组合函数并学习如何同时处理多个Observables来创建我们想要的Observable。