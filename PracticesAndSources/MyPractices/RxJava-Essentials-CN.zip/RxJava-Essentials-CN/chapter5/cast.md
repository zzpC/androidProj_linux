# Cast

RxJava的`cast()`函数是本章中最后一个操作符。它是`map()`操作符的特殊版本。它将源Observable中的每一项数据都转换为新的类型，把它变成了不同的`Class`。

![](../images/chapter5_15.png)

