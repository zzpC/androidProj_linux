# RxJava观察者模式工具包

在RxJava的世界里，我们有四种角色：
* Observable
* Observer
* Subscriber
* Subjects

Observables和Subjects是两个“生产”实体，Observers和Subscribers是两个“消费”实体。