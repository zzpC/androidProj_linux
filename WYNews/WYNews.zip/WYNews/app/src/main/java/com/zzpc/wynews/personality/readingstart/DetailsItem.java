package com.zzpc.wynews.personality.readingstart;

/**
 * Created by zzp on 18-2-21.
 */
class DetailsItem {
    String mTitle;
    String mContent;
    DetailsItem(String title,String content) {
        super();
        mTitle=title;
        mContent=content;
    }
}