package com.zzpc.wynews.personality.readinghistory;

/**
 * Created by zzp on 18-2-21.
 */
class MyHistoryItem {
    String mTitle;
    String mContent;
    MyHistoryItem(String title, String content) {
        super();
        mTitle=title;
        mContent=content;
    }
}