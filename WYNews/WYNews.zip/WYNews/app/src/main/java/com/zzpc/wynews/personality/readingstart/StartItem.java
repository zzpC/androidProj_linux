package com.zzpc.wynews.personality.readingstart;

/**
 * Created by zzp on 18-2-21.
 */

public class StartItem {
    String mTheme;
    StartItem(String theme) {
        mTheme=theme;
    }
}