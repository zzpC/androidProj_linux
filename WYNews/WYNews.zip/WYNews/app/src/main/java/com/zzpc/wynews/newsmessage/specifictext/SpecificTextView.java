package com.zzpc.wynews.newsmessage.specifictext;

public interface SpecificTextView {
    void showResultFromNet(String title,String content);
}
