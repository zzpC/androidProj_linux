package com.zzpc.wynews.newsmessage;



public interface MessageView {
    void initTabs();
    void deleteTab(int position);
    void initViewPagerAndTabLayout();
}
